import UIKit

var greeting = "Hello, playground"
var distance : Double
var maxWeight : Int = 130
print("Your max weight is \()")
